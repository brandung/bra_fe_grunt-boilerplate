bra-module-widget
=================

Insert widget in _modules.html for quick navigation to each module element on page
